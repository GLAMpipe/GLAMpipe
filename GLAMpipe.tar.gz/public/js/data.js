
var dataHolder = function () {
	var self = this;
	this.workspaceDiv = "dataspace"



}
